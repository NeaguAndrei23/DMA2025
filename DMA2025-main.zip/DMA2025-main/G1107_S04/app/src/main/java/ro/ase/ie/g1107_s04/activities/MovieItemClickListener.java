package ro.ase.ie.g1107_s04.activities;

public interface MovieItemClickListener {


    public void onMovieClick(int position);
}
