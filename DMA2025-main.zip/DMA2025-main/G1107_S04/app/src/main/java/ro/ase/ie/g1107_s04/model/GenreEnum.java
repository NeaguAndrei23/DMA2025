package ro.ase.ie.g1107_s04.model;

public enum GenreEnum {
    Drama,
    Comedy,
    Action,
    Adventure
}
