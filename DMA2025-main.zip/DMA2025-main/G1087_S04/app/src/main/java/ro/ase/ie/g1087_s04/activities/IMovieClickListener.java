package ro.ase.ie.g1087_s04.activities;

public interface IMovieClickListener {
    public void onMovieCLick(int position);
    public void onMovieDelete(int position);
}
