package ro.ase.ie.g1087_s04.model;

public enum GenreEnum {
    Drama,
    Action,
    Comedy,
    Adventure
}
