package ro.ase.ie.g1087_s04.model;

public enum ParentalApprovalEnum {
    G,
    PG,
    PG13,
    R,
    NC17
}
