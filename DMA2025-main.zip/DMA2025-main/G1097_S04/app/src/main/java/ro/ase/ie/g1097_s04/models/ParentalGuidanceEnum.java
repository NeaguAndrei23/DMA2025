package ro.ase.ie.g1097_s04.models;

public enum ParentalGuidanceEnum {
    G,
    PG,
    PG13,
    R,
    NC17
}
