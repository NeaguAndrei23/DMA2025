package ro.ase.ie.g1097_s04.activities;

public interface IMovieEventListener {
    public void onMovieItemClick(int position);
}
