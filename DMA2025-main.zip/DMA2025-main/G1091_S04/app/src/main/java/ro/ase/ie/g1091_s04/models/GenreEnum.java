package ro.ase.ie.g1091_s04.models;

public enum GenreEnum {
    Drama,
    Action,
    Comedy,
    Adventure
}
