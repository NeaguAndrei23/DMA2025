package ro.ase.ie.g1091_s04.activities;

public interface IMovieEventListener {
    public void onMovieItemClick(int position);
    public void onMovieDelete(int position);

}
