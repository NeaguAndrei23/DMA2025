package ro.ase.ie.g1106_s04.model;

public enum ParentalGuidanceEnum {
    G,
    PG,
    PG13,
    R,
    NC17
}
