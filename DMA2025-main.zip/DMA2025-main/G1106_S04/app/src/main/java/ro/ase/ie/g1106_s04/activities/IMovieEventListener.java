package ro.ase.ie.g1106_s04.activities;

public interface IMovieEventListener {
    void onMovieClick(int position);
    void onMovieDelete(int position);
}
